Role Based Access Control :


This is a Role Based Access Control application using Nodejs, Express, Passport Js, etc.
For authentication we have only Email & Password option 

The application is based on the MVC pattern i.e. Model View Controller.

Mongoose is used as an ORM for MongoDB for storing Users in Database.

Passport JS is used for local(email, password) authentication.